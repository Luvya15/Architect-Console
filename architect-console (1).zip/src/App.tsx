import React, { useState, useEffect } from 'react';
import { ServiceIntegrator, QueueItem } from './types';
import ConsoleTab from './components/ConsoleTab';
import ToolboxTab from './components/ToolboxTab';
import TraceTab from './components/TraceTab';
import GuardrailsTab from './components/GuardrailsTab';
import { motion, AnimatePresence } from 'motion/react';

const INITIAL_INTEGRATORS: ServiceIntegrator[] = [
  {
    id: 'shopify-api',
    name: 'Shopify Admin API',
    version: 'v2024-04 Stable',
    icon: 'shopping_bag',
    color: '#818cf8',
    capabilities: ['Read Orders', 'Write Orders'],
    protocol: 'MCP Gateway',
    healthScore: 98,
    authStatus: 'AUTHORIZED',
    lastSync: '2026-06-25 14:32:01 UTC',
    latencyTarget: '98% Latency Target'
  },
  {
    id: 'stripe-api',
    name: 'Stripe API',
    version: 'Secret Key Rotation: 12d',
    icon: 'payments',
    color: '#635BFF',
    capabilities: ['Refunds'],
    protocol: 'Direct Connect',
    healthScore: 100,
    authStatus: 'AUTHORIZED',
    lastSync: '2026-06-25 15:10:44 UTC',
    latencyTarget: '100% Operational'
  },
  {
    id: 'fedex-api',
    name: 'FedEx API',
    version: 'Legacy SOAP Bridge',
    icon: 'local_shipping',
    color: '#a78bfa',
    capabilities: ['Label Gen'],
    protocol: 'MCP Gateway',
    healthScore: 74,
    authStatus: 'AUTHORIZED',
    lastSync: '2026-06-25 11:20:00 UTC',
    latencyTarget: 'Degraded Latency'
  },
  {
    id: 'riskified-api',
    name: 'Riskified',
    version: 'Security Analysis',
    icon: 'gpp_maybe',
    color: '#f472b6',
    capabilities: ['Fraud Score'],
    protocol: 'MCP Gateway',
    healthScore: 94,
    authStatus: 'EXPIRED',
    lastSync: '2026-06-25 09:15:30 UTC',
    latencyTarget: 'Stable'
  }
];

const INITIAL_QUEUE: QueueItem[] = [
  {
    id: 'inc-1',
    timestamp: '14:02:11',
    modelNode: 'Inference-Cluster-A',
    riskFactor: 'Data Leakage?',
    riskSeverity: 'critical',
    ambiguityScore: 88,
    status: 'Awaiting Review',
    details: 'Customer Sarah Jenkins return rate check triggered leak safety score of 88% due to active PII match indicators.'
  },
  {
    id: 'inc-2',
    timestamp: '13:58:45',
    modelNode: 'User-Auth-Gateway',
    riskFactor: 'Tone Violation',
    riskSeverity: 'moderate',
    ambiguityScore: 62,
    status: 'Awaiting Review',
    details: 'Linguistic verification node reported extreme aggressive style indicators matching tone policy guidelines.'
  },
  {
    id: 'inc-3',
    timestamp: '13:45:02',
    modelNode: 'Legacy-Bridge-v1',
    riskFactor: 'Protocol Mismatch',
    riskSeverity: 'low',
    ambiguityScore: 45,
    status: 'Being Handled',
    assignedTo: 'J. Doe',
    details: 'Communication frame mismatch. J. Doe has locked the incident queue for active forensic audit checks.'
  }
];

export default function App() {
  const [activeTab, setActiveTab] = useState<'console' | 'toolbox' | 'trace' | 'guardrails'>('console');
  
  // App-wide state
  const [policyElasticity, setPolicyElasticity] = useState<number>(15);
  const [autoAdjudication, setAutoAdjudication] = useState<boolean>(true);
  const [integrators, setIntegrators] = useState<ServiceIntegrator[]>(INITIAL_INTEGRATORS);
  
  const [keyRotation, setKeyRotation] = useState<boolean>(true);
  const [piiMasking, setPiiMasking] = useState<boolean>(true);
  const [contextIsolation, setContextIsolation] = useState<boolean>(false);
  
  const [complianceScore, setComplianceScore] = useState<number>(94.8);
  const [blockedThreats, setBlockedThreats] = useState<number>(1402);
  const [queue, setQueue] = useState<QueueItem[]>(INITIAL_QUEUE);

  // Quick Action / Alert Drawer from Floating Action Button (FAB)
  const [showQuickAction, setShowQuickAction] = useState(false);

  // Live dynamic clock state
  const [timeStr, setTimeStr] = useState('22:48');

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      const hrs = String(now.getHours()).padStart(2, '0');
      const mins = String(now.getMinutes()).padStart(2, '0');
      setTimeStr(`${hrs}:${mins}`);
    };
    updateTime();
    const interval = setInterval(updateTime, 10000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="min-h-screen bg-[#020205] text-white font-sans pb-24 md:pb-12 relative overflow-hidden">
      {/* Ambient background glow matching Immersive UI */}
      <div className="ambient-glow-wrapper">
        <div className="ambient-blob-1" />
        <div className="ambient-blob-2" />
        <div className="ambient-blob-3" />
      </div>

      {/* TopAppBar */}
      <header className="relative w-full top-0 sticky border-b border-white/5 bg-[#020205]/60 backdrop-blur-md z-40 flex justify-between items-center px-lg py-md">
        <div 
          onClick={() => setActiveTab('console')}
          className="flex items-center gap-md cursor-pointer group"
        >
          <div className="w-10 h-10 rounded-full bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center shadow-[0_0_20px_rgba(99,102,241,0.4)] group-hover:scale-105 transition-transform">
            <span className="font-bold text-base text-white font-headline">A</span>
          </div>
          <div>
            <h1 className="font-headline text-sm font-semibold tracking-wider uppercase text-white">
              Architect Console
            </h1>
            <p className="text-[9px] text-indigo-400/80 uppercase tracking-[0.2em] font-mono">
              Sentinel Station Alpha
            </p>
          </div>
        </div>
        
        <div className="flex items-center gap-lg">
          <nav className="hidden md:flex gap-md items-center mr-4">
            <button 
              id="nav-console-tab"
              onClick={() => setActiveTab('console')}
              className={`font-headline text-xs uppercase tracking-wider transition-all px-md py-2 rounded-lg cursor-pointer ${activeTab === 'console' ? 'text-[#818cf8] bg-white/[0.04] border border-[#818cf8]/30 shadow-[0_0_15px_rgba(99,102,241,0.15)] font-bold' : 'text-white/60 hover:bg-white/[0.02] hover:text-white'}`}
            >
              Console
            </button>
            <button 
              id="nav-toolbox-tab"
              onClick={() => setActiveTab('toolbox')}
              className={`font-headline text-xs uppercase tracking-wider transition-all px-md py-2 rounded-lg cursor-pointer ${activeTab === 'toolbox' ? 'text-[#818cf8] bg-white/[0.04] border border-[#818cf8]/30 shadow-[0_0_15px_rgba(99,102,241,0.15)] font-bold' : 'text-white/60 hover:bg-white/[0.02] hover:text-white'}`}
            >
              Toolbox
            </button>
            <button 
              id="nav-trace-tab"
              onClick={() => setActiveTab('trace')}
              className={`font-headline text-xs uppercase tracking-wider transition-all px-md py-2 rounded-lg cursor-pointer ${activeTab === 'trace' ? 'text-[#818cf8] bg-white/[0.04] border border-[#818cf8]/30 shadow-[0_0_15px_rgba(99,102,241,0.15)] font-bold' : 'text-white/60 hover:bg-white/[0.02] hover:text-white'}`}
            >
              Trace
            </button>
            <button 
              id="nav-guardrails-tab"
              onClick={() => setActiveTab('guardrails')}
              className={`font-headline text-xs uppercase tracking-wider transition-all px-md py-2 rounded-lg cursor-pointer ${activeTab === 'guardrails' ? 'text-[#818cf8] bg-white/[0.04] border border-[#818cf8]/30 shadow-[0_0_15px_rgba(99,102,241,0.15)] font-bold' : 'text-white/60 hover:bg-white/[0.02] hover:text-white'}`}
            >
              Guardrails
            </button>
          </nav>

          {/* Environmental parameter widgets from Design HTML */}
          <div className="hidden md:flex items-center gap-6 text-right mr-2">
            <div className="flex flex-col items-end">
              <span className="text-lg font-light tracking-tight text-white font-headline">24.5°C</span>
              <span className="text-[8px] text-white/40 uppercase tracking-widest font-mono">Ambient Temp</span>
            </div>
            <div className="w-px h-8 bg-white/10"></div>
            <div className="flex flex-col items-end">
              <span className="text-lg font-light tracking-tight text-white font-headline">{timeStr}</span>
              <span className="text-[8px] text-white/40 uppercase tracking-widest font-mono">Standard Time</span>
            </div>
          </div>

          <div className="w-9 h-9 rounded-full border border-white/10 p-0.5 shadow-md shadow-indigo-500/5">
            <div className="w-full h-full rounded-full bg-slate-800 overflow-hidden">
              <img 
                className="w-full h-full object-cover" 
                alt="Tech Architect Portrait" 
                src="https://lh3.googleusercontent.com/aida-public/AB6AXuDHRZeFmJKbOWAZx-e6vHg1SGgNrjc25wVuPJyk1KXlTaJ2QkEw8focr9GIFRpmljXu06CtfI32NYFCbScfiTfiv9Jt7hBQX0Zv3NDUsePs5YWR9jE1PPymAShrfnVSkh3Nse27hGeB-9DTUGdSEMZUq9Bka-6Zg2TH775YiAbAKowq67K9Pz4pfxrESZUAVqD5pZDGDMS0yKMMF5oDzK3oTfDBZhgzyl0ie-ZEolxfXO3M_CKtnoQIkqI1M-2SfavpNsyOV7Grw5Q" 
              />
            </div>
          </div>
        </div>
      </header>

      {/* Main Container */}
      <main className="max-w-container-max mx-auto px-lg py-xl">
        <AnimatePresence mode="wait">
          <motion.div
            key={activeTab}
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            transition={{ duration: 0.15 }}
          >
            {activeTab === 'console' && (
              <ConsoleTab 
                policyElasticity={policyElasticity}
                setPolicyElasticity={setPolicyElasticity}
                autoAdjudication={autoAdjudication}
                setAutoAdjudication={setAutoAdjudication}
                onNavigateToTrace={() => setActiveTab('trace')}
              />
            )}

            {activeTab === 'toolbox' && (
              <ToolboxTab 
                integrators={integrators}
                setIntegrators={setIntegrators}
                keyRotation={keyRotation}
                setKeyRotation={setKeyRotation}
                piiMasking={piiMasking}
                setPiiMasking={setPiiMasking}
                contextIsolation={contextIsolation}
                setContextIsolation={setContextIsolation}
              />
            )}

            {activeTab === 'trace' && (
              <TraceTab 
                complianceScore={complianceScore}
                setComplianceScore={setComplianceScore}
                logisticsCapacity={policyElasticity}
              />
            )}

            {activeTab === 'guardrails' && (
              <GuardrailsTab 
                queue={queue}
                setQueue={setQueue}
                blockedThreats={blockedThreats}
                setBlockedThreats={setBlockedThreats}
              />
            )}
          </motion.div>
        </AnimatePresence>
      </main>

      {/* BottomNavBar (Mobile only) */}
      <nav className="md:hidden fixed bottom-0 left-0 w-full z-40 flex justify-around items-center pt-sm pb-lg px-md border-t border-outline-variant/20 bg-surface-container-lowest/95 backdrop-blur-lg rounded-t-xl">
        <button 
          id="mobile-nav-console"
          onClick={() => setActiveTab('console')}
          className={`flex flex-col items-center justify-center py-1 px-4 rounded-full transition-all duration-200 active:scale-90 ${activeTab === 'console' ? 'bg-primary-container text-on-primary-container shadow-md' : 'text-on-surface-variant'}`}
        >
          <span className="material-symbols-outlined text-xl">psychology</span>
          <span className="text-[10px] font-semibold mt-0.5 font-headline">Console</span>
        </button>
        <button 
          id="mobile-nav-toolbox"
          onClick={() => setActiveTab('toolbox')}
          className={`flex flex-col items-center justify-center py-1 px-4 rounded-full transition-all duration-200 active:scale-90 ${activeTab === 'toolbox' ? 'bg-primary-container text-on-primary-container shadow-md' : 'text-on-surface-variant'}`}
        >
          <span className="material-symbols-outlined text-xl">extension</span>
          <span className="text-[10px] font-semibold mt-0.5 font-headline">Toolbox</span>
        </button>
        <button 
          id="mobile-nav-trace"
          onClick={() => setActiveTab('trace')}
          className={`flex flex-col items-center justify-center py-1 px-4 rounded-full transition-all duration-200 active:scale-90 ${activeTab === 'trace' ? 'bg-primary-container text-on-primary-container shadow-md' : 'text-on-surface-variant'}`}
        >
          <span className="material-symbols-outlined text-xl">query_stats</span>
          <span className="text-[10px] font-semibold mt-0.5 font-headline">Trace</span>
        </button>
        <button 
          id="mobile-nav-guardrails"
          onClick={() => setActiveTab('guardrails')}
          className={`flex flex-col items-center justify-center py-1 px-4 rounded-full transition-all duration-200 active:scale-90 ${activeTab === 'guardrails' ? 'bg-primary-container text-on-primary-container shadow-md' : 'text-on-surface-variant'}`}
        >
          <span className="material-symbols-outlined text-xl">security</span>
          <span className="text-[10px] font-semibold mt-0.5 font-headline">Guardrails</span>
        </button>
      </nav>

      {/* Interactive FAB for security quick report */}
      <button 
        onClick={() => setShowQuickAction(true)}
        className="fixed bottom-lg right-lg w-14 h-14 bg-primary text-on-primary rounded-full shadow-lg flex items-center justify-center hover:scale-110 active:scale-95 transition-all z-35 cursor-pointer hover:shadow-primary/20 hover:shadow-xl"
        title="Open Security quick-status audit"
      >
        <span className="material-symbols-outlined text-2xl">add_moderator</span>
      </button>

      {/* Quick Status Drawer */}
      <AnimatePresence>
        {showQuickAction && (
          <div className="fixed inset-0 bg-black/50 backdrop-blur-xs z-50 flex justify-end">
            <div 
              className="fixed inset-0" 
              onClick={() => setShowQuickAction(false)}
            />
            <motion.div 
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              className="glass-panel w-full max-w-sm h-full bg-[#020205]/95 backdrop-blur-md border-l border-white/10 relative z-10 p-lg flex flex-col justify-between"
            >
              <div className="space-y-lg">
                <div className="flex justify-between items-center pb-md border-b border-outline-variant/15">
                  <div className="flex items-center gap-2">
                    <span className="material-symbols-outlined text-primary">security</span>
                    <h3 className="font-headline text-base font-bold text-on-surface">Architect Quick Audit</h3>
                  </div>
                  <button 
                    onClick={() => setShowQuickAction(false)}
                    className="p-1 hover:bg-surface-container-highest rounded-full text-on-surface-variant cursor-pointer"
                  >
                    <span className="material-symbols-outlined">close</span>
                  </button>
                </div>

                <div className="space-y-md">
                  <div className="bg-surface-container p-md rounded-xl space-y-2 border border-outline-variant/10">
                    <div className="text-[10px] text-on-surface-variant uppercase tracking-wider font-bold">Consolidated Status</div>
                    <div className="flex items-center gap-2">
                      <div className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse"></div>
                      <span className="text-sm font-bold text-on-surface font-headline">ALL SUB-SYSTEMS CONVERGED</span>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <div className="text-[10px] text-on-surface-variant uppercase tracking-wider font-bold">Active Shield Indicators</div>
                    <div className="space-y-2.5">
                      <div className="flex justify-between text-xs">
                        <span className="text-on-surface-variant">Policy Elasticity Limit:</span>
                        <span className="font-mono text-tertiary font-bold">{policyElasticity}%</span>
                      </div>
                      <div className="flex justify-between text-xs">
                        <span className="text-on-surface-variant">Auto-Adjudication status:</span>
                        <span className={`font-semibold ${autoAdjudication ? 'text-emerald-400' : 'text-on-surface-variant'}`}>{autoAdjudication ? 'Strict ENFORCE' : 'MANUAL'}</span>
                      </div>
                      <div className="flex justify-between text-xs">
                        <span className="text-on-surface-variant">PII Masking protocol:</span>
                        <span className={`font-semibold ${piiMasking ? 'text-primary' : 'text-on-surface-variant'}`}>{piiMasking ? 'ACTIVE' : 'OFF'}</span>
                      </div>
                      <div className="flex justify-between text-xs">
                        <span className="text-on-surface-variant">Context Isolation level:</span>
                        <span className={`font-semibold ${contextIsolation ? 'text-primary' : 'text-on-surface-variant'}`}>{contextIsolation ? 'ACTIVE' : 'STANDARD'}</span>
                      </div>
                    </div>
                  </div>

                  <div className="pt-2 border-t border-outline-variant/10">
                    <div className="text-[10px] text-on-surface-variant uppercase tracking-wider font-bold mb-2">Unresolved Exceptions</div>
                    <div className="p-3 bg-amber-500/10 border border-amber-500/20 rounded-xl flex items-center justify-between text-xs text-amber-300">
                      <span>{queue.filter(i => i.status === 'Awaiting Review').length} issues await verification</span>
                      <button 
                        onClick={() => {
                          setShowQuickAction(false);
                          setActiveTab('guardrails');
                        }}
                        className="text-[10px] bg-amber-500 text-black font-headline font-bold px-2 py-1 rounded"
                      >
                        FIX NOW
                      </button>
                    </div>
                  </div>
                </div>
              </div>

              <div className="space-y-2 pt-4 border-t border-outline-variant/15">
                <button 
                  onClick={() => {
                    setShowQuickAction(false);
                    setPolicyElasticity(15);
                    setAutoAdjudication(true);
                    setPiiMasking(true);
                    setKeyRotation(true);
                    setContextIsolation(false);
                  }}
                  className="w-full py-2 border border-outline-variant hover:bg-surface-container-highest text-on-surface rounded-lg text-xs font-headline font-semibold text-center cursor-pointer"
                >
                  Factory Reset Sentinel Policies
                </button>
                <div className="text-[10px] text-on-surface-variant text-center font-mono">
                  Sentinel Security Core v4.2.0-stable
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
