import React, { useRef, useState, useEffect } from 'react';
import * as d3 from 'd3';

interface ComplianceLineChartProps {
  complianceScore: number;
}

interface DataPoint {
  day: number;
  date: string;
  score: number;
}

// 30 days historical data blueprint (slightly fluctuating around 93-95%)
const BASE_SCORES = [
  92.4, 92.8, 92.1, 93.0, 93.5, 
  93.2, 93.9, 93.6, 94.2, 93.8, 
  94.5, 94.1, 94.9, 94.6, 94.2, 
  94.8, 94.4, 95.1, 94.7, 95.3, 
  94.8, 95.4, 95.1, 95.5, 95.0, 
  95.6, 95.2, 95.8, 95.4, 94.8
];

export default function ComplianceLineChart({ complianceScore }: ComplianceLineChartProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const [dimensions, setDimensions] = useState({ width: 340, height: 160 });
  const [hoveredPoint, setHoveredPoint] = useState<DataPoint | null>(null);
  const [hoverCoords, setHoverCoords] = useState<{ x: number; y: number } | null>(null);

  const gXRef = useRef<SVGGElement>(null);
  const gYRef = useRef<SVGGElement>(null);

  // Auto-resize handler (debounced using requestAnimationFrame)
  useEffect(() => {
    if (!containerRef.current) return;
    
    let animationFrameId: number;
    const resizeObserver = new ResizeObserver((entries) => {
      for (let entry of entries) {
        const { width, height } = entry.contentRect;
        cancelAnimationFrame(animationFrameId);
        animationFrameId = requestAnimationFrame(() => {
          setDimensions({
            width: width || 340,
            height: height || 160
          });
        });
      }
    });
    
    resizeObserver.observe(containerRef.current);
    return () => {
      resizeObserver.disconnect();
      cancelAnimationFrame(animationFrameId);
    };
  }, []);

  // Generate 30 days of data mapped smoothly to end on complianceScore
  const data: DataPoint[] = React.useMemo(() => {
    return Array.from({ length: 30 }, (_, i) => {
      const daysAgo = 29 - i;
      const date = new Date();
      date.setDate(date.getDate() - daysAgo);
      const dateStr = date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });

      // Scale base values so the final day perfectly hits the current state-driven complianceScore
      const baseValue = BASE_SCORES[i % BASE_SCORES.length];
      const finalBaseValue = BASE_SCORES[BASE_SCORES.length - 1];
      const diff = complianceScore - finalBaseValue;
      
      // Interpolate the delta across the timeline so transitions are continuous
      const interpolationFactor = (i + 1) / 30;
      const scoreValue = baseValue + (diff * interpolationFactor);

      return {
        day: i + 1,
        date: dateStr,
        score: parseFloat(Math.min(100, Math.max(0, scoreValue)).toFixed(1))
      };
    });
  }, [complianceScore]);

  // Margin-convention setup
  const margin = { top: 15, right: 10, bottom: 25, left: 35 };
  const { width, height } = dimensions;
  const chartWidth = Math.max(50, width - margin.left - margin.right);
  const chartHeight = Math.max(40, height - margin.top - margin.bottom);

  // Scales
  const xScale = React.useMemo(() => {
    return d3.scaleLinear()
      .domain([1, 30])
      .range([0, chartWidth]);
  }, [chartWidth]);

  const yScale = React.useMemo(() => {
    const scores = data.map(d => d.score);
    const minScore = d3.min(scores) || 90;
    const maxScore = d3.max(scores) || 100;
    
    const yDomainMin = Math.max(0, Math.floor(minScore - 1));
    const yDomainMax = Math.min(100, Math.ceil(maxScore + 1));

    return d3.scaleLinear()
      .domain([yDomainMin, yDomainMax])
      .range([chartHeight, 0]);
  }, [chartHeight, data]);

  // Draw axis ticks and horizontal gridlines
  useEffect(() => {
    if (!gXRef.current || !gYRef.current) return;

    // Tick selection for X-axis: 1st day, 10th day, 20th day, 30th day
    const xAxis = d3.axisBottom(xScale)
      .tickValues([1, 10, 20, 30])
      .tickFormat((d) => {
        const idx = (d as number) - 1;
        return data[idx] ? data[idx].date : '';
      })
      .tickSize(4);

    // Ticks for Y-axis: show 3 indicators
    const yAxis = d3.axisLeft(yScale)
      .ticks(3)
      .tickFormat(d => `${d}%`)
      .tickSize(-chartWidth);

    d3.select(gXRef.current)
      .call(xAxis)
      .call(g => g.select(".domain").remove()) // clean look
      .call(g => g.selectAll(".tick text")
        .attr("fill", "rgba(255, 255, 255, 0.45)")
        .attr("font-size", "9px")
        .attr("font-family", "var(--font-mono)")
      )
      .call(g => g.selectAll(".tick line")
        .attr("stroke", "rgba(255, 255, 255, 0.1)")
      );

    d3.select(gYRef.current)
      .call(yAxis)
      .call(g => g.select(".domain").remove())
      .call(g => g.selectAll(".tick text")
        .attr("fill", "rgba(255, 255, 255, 0.45)")
        .attr("font-size", "9px")
        .attr("font-family", "var(--font-mono)")
        .attr("dx", "-2px")
      )
      .call(g => g.selectAll(".tick line")
        .attr("stroke", "rgba(255, 255, 255, 0.04)")
        .attr("stroke-dasharray", "2,2")
      );
  }, [xScale, yScale, chartWidth, data]);

  // Path generators
  const linePath = React.useMemo(() => {
    const lineGenerator = d3.line<DataPoint>()
      .x(d => xScale(d.day))
      .y(d => yScale(d.score))
      .curve(d3.curveMonotoneX);
    return lineGenerator(data) || '';
  }, [xScale, yScale, data]);

  const areaPath = React.useMemo(() => {
    const areaGenerator = d3.area<DataPoint>()
      .x(d => xScale(d.day))
      .y0(chartHeight)
      .y1(d => yScale(d.score))
      .curve(d3.curveMonotoneX);
    return areaGenerator(data) || '';
  }, [xScale, yScale, chartHeight, data]);

  // Interactive mouse tracking
  const handleMouseMove = (event: React.MouseEvent<SVGSVGElement, MouseEvent>) => {
    if (!chartWidth || !chartHeight) return;
    const svg = event.currentTarget;
    const rect = svg.getBoundingClientRect();
    const mouseX = event.clientX - rect.left - margin.left;

    if (mouseX < -10 || mouseX > chartWidth + 10) {
      setHoveredPoint(null);
      setHoverCoords(null);
      return;
    }

    // Invert X mouse coordinate to day value (1 to 30)
    const dayValue = xScale.invert(Math.max(0, Math.min(chartWidth, mouseX)));
    const roundedDay = Math.round(dayValue);
    const point = data.find(d => d.day === roundedDay);

    if (point) {
      setHoveredPoint(point);
      setHoverCoords({
        x: xScale(point.day) + margin.left,
        y: yScale(point.score) + margin.top
      });
    }
  };

  const handleMouseLeave = () => {
    setHoveredPoint(null);
    setHoverCoords(null);
  };

  const isRightHalf = hoverCoords && hoverCoords.x > width / 2;

  return (
    <div ref={containerRef} className="w-full h-full relative" id="compliance-chart-container">
      {/* Floating Interactive Tooltip */}
      {hoveredPoint && hoverCoords && (
        <div
          className="absolute z-20 pointer-events-none bg-slate-950/90 border border-[#818cf8]/30 px-2.5 py-1.5 rounded-lg text-[9px] shadow-lg shadow-black/40 backdrop-blur-sm transition-all duration-75"
          style={{
            left: isRightHalf ? hoverCoords.x - 105 : hoverCoords.x + 10,
            top: hoverCoords.y - 45,
            fontFamily: 'var(--font-mono)'
          }}
        >
          <div className="text-white/40 uppercase tracking-widest text-[8px] font-semibold">{hoveredPoint.date}</div>
          <div className="flex items-center gap-1.5 mt-0.5">
            <span className="w-1.5 h-1.5 rounded-full bg-[#818cf8] shadow-[0_0_6px_#818cf8]" />
            <span className="text-white font-bold text-xs">Score: {hoveredPoint.score}%</span>
          </div>
        </div>
      )}

      <svg
        width={width}
        height={height}
        onMouseMove={handleMouseMove}
        onMouseLeave={handleMouseLeave}
        className="overflow-visible cursor-crosshair block"
      >
        <defs>
          {/* Stroke Gradient */}
          <linearGradient id="line-grad" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="#6366f1" />
            <stop offset="60%" stopColor="#818cf8" />
            <stop offset="100%" stopColor="#f472b6" />
          </linearGradient>

          {/* Area under line Glow Gradient */}
          <linearGradient id="area-grad" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="#6366f1" stopOpacity="0.18" />
            <stop offset="100%" stopColor="#6366f1" stopOpacity="0.00" />
          </linearGradient>

          {/* Core glow filter for glowing line */}
          <filter id="glow" x="-20%" y="-20%" width="140%" height="140%">
            <feGaussianBlur stdDeviation="3" result="blur" />
            <feMerge>
              <feMergeNode in="blur" />
              <feMergeNode in="SourceGraphic" />
            </feMerge>
          </filter>
        </defs>

        {/* Chart group with margins */}
        <g transform={`translate(${margin.left}, ${margin.top})`}>
          {/* Ticks & Gridlines */}
          <g ref={gXRef} transform={`translate(0, ${chartHeight})`} />
          <g ref={gYRef} />

          {/* Area Fill */}
          <path
            d={areaPath}
            fill="url(#area-grad)"
            className="transition-all duration-300"
          />

          {/* Outer glowing trace line (blur) */}
          <path
            d={linePath}
            fill="none"
            stroke="url(#line-grad)"
            strokeWidth="3.5"
            opacity="0.3"
            filter="url(#glow)"
            className="transition-all duration-300"
          />

          {/* Core crisp trace line */}
          <path
            d={linePath}
            fill="none"
            stroke="url(#line-grad)"
            strokeWidth="1.75"
            strokeLinecap="round"
            className="transition-all duration-300"
          />
        </g>

        {/* Hover elements */}
        {hoveredPoint && hoverCoords && (
          <>
            {/* Guide line */}
            <line
              x1={hoverCoords.x}
              y1={margin.top}
              x2={hoverCoords.x}
              y2={chartHeight + margin.top}
              stroke="rgba(129, 140, 248, 0.2)"
              strokeWidth="1"
              strokeDasharray="3,3"
            />

            {/* Glowing tracer node */}
            <circle
              cx={hoverCoords.x}
              cy={hoverCoords.y}
              r="7"
              fill="rgba(99, 102, 241, 0.25)"
              className="animate-ping"
            />
            <circle
              cx={hoverCoords.x}
              cy={hoverCoords.y}
              r="4.5"
              fill="#818cf8"
              stroke="#ffffff"
              strokeWidth="1.25"
              style={{ filter: 'drop-shadow(0 0 5px #818cf8)' }}
            />
          </>
        )}
      </svg>
    </div>
  );
}
