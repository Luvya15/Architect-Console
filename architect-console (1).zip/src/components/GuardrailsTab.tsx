import React, { useState } from 'react';
import { QueueItem } from '../types';
import { motion, AnimatePresence } from 'motion/react';

interface GuardrailsTabProps {
  queue: QueueItem[];
  setQueue: React.Dispatch<React.SetStateAction<QueueItem[]>>;
  blockedThreats: number;
  setBlockedThreats: React.Dispatch<React.SetStateAction<number>>;
}

export default function GuardrailsTab({
  queue,
  setQueue,
  blockedThreats,
  setBlockedThreats,
}: GuardrailsTabProps) {
  const [selectedIncident, setSelectedIncident] = useState<QueueItem | null>(null);
  const [showTimeoutModal, setShowTimeoutModal] = useState(false);
  const [timeoutLimit, setTimeoutLimit] = useState(5000);
  const [timeoutStrategy, setTimeoutStrategy] = useState('Exponential Backoff');
  const [timeoutFallback, setTimeoutFallback] = useState('Local TinyLlama');

  const [showForensicLogs, setShowForensicLogs] = useState(false);

  // Simulated forensic log array
  const [forensicLogs, setForensicLogs] = useState<string[]>([
    "[SEC-AUDIT-01] BLOCKED: Inbound payload contain 'Ignore previous rules' pattern.",
    "[SEC-AUDIT-02] REDACTED: Customer tax code matched PII scanner filter (0.00% leak rate).",
    "[SEC-AUDIT-03] ESCALATION: Unregistered API payload format matched 'Protocol Mismatch' score 45%.",
    "[SEC-AUDIT-04] BLOCKED: Anomaly signature detected - transaction speed from Sarah Jenkins account: 4 requests within 0.1s.",
    "[SEC-AUDIT-05] SUSPICIOUS: Large token deviation index on Inference-Cluster-A (Ambiguity 88%)."
  ]);

  const handleAuditAll = () => {
    setQueue(prev => prev.map(item => {
      if (item.status === 'Awaiting Review') {
        return { ...item, status: 'Resolved' };
      }
      return item;
    }));
    setBlockedThreats(prev => prev + queue.filter(item => item.status === 'Awaiting Review').length);
  };

  const handleRefreshQueue = () => {
    const timestamps = ['14:24:12', '14:20:05', '14:15:33', '14:11:00'];
    const nodes = ['Inference-Cluster-B', 'Edge-Ingest-02', 'API-Route-Secure', 'Model-Core-Sentinel'];
    const factors: Array<QueueItem['riskFactor']> = ['High Return Rate', 'Prompt Injection', 'Data Leakage?', 'Tone Violation'];
    const severities: Array<QueueItem['riskSeverity']> = ['critical', 'moderate', 'low', 'moderate'];

    const randomIdx = Math.floor(Math.random() * 4);
    const newIncident: QueueItem = {
      id: Math.random().toString(),
      timestamp: timestamps[randomIdx],
      modelNode: nodes[randomIdx],
      riskFactor: factors[randomIdx],
      riskSeverity: severities[randomIdx],
      ambiguityScore: Math.floor(Math.random() * 40) + 50,
      status: 'Awaiting Review',
      details: `Simulated anomaly triggered on security layer ${nodes[randomIdx]}. Dynamic review threshold checked.`
    };

    setQueue(prev => [newIncident, ...prev]);
  };

  const handleResolveIncident = (status: 'Resolved' | 'Flagged') => {
    if (!selectedIncident) return;
    setQueue(prev => prev.map(item => {
      if (item.id === selectedIncident.id) {
        return { ...item, status };
      }
      return item;
    }));
    if (status === 'Flagged') {
      setBlockedThreats(prev => prev + 1);
    }
    setSelectedIncident(null);
  };

  return (
    <div className="space-y-xl" id="guardrails-tab-container">
      {/* Dashboard Header */}
      <section className="flex flex-col md:flex-row justify-between items-start md:items-end gap-lg">
        <div>
          <h2 className="font-headline text-headline-lg text-on-surface">Guardrails &amp; Safety</h2>
          <p className="text-on-surface-variant font-sans text-body-md mt-1 max-w-2xl leading-relaxed">
            Real-time monitoring of automated defense routines, safety score auditing, and manual exception handling queues.
          </p>
        </div>
        <div className="flex gap-md bg-surface-container-high p-3 rounded-xl border border-outline-variant/10 shadow-md">
          <div className="px-md py-1 border-r border-outline-variant/20">
            <div className="text-[10px] text-on-surface-variant uppercase tracking-wider font-semibold font-headline">System Health</div>
            <div className="flex items-center gap-1.5 mt-1 font-mono text-sm font-bold">
              <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></div>
              <span className="text-emerald-400">99.98%</span>
            </div>
          </div>
          <div className="px-md py-1">
            <div className="text-[10px] text-on-surface-variant uppercase tracking-wider font-semibold font-headline">Blocked Threats</div>
            <div className="font-mono text-on-surface font-bold text-sm mt-1">{blockedThreats} / 24h</div>
          </div>
        </div>
      </section>

      {/* Bento Grid Layout */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-lg">
        {/* Safety Metrics (4 columns on desktop) */}
        <div className="md:col-span-4 space-y-lg flex flex-col justify-between">
          <div className="glass-panel rounded-xl p-lg border border-outline-variant/15 flex-grow">
            <div className="flex justify-between items-center mb-4">
              <h3 className="font-headline text-xs font-semibold text-on-surface-variant uppercase tracking-widest">Active Guardrails</h3>
              <span className="material-symbols-outlined text-primary">security</span>
            </div>
            
            <div className="space-y-3">
              {/* Guardrail: Prompt Injection */}
              <div className="guardrail-glow-emerald bg-surface-container/30 p-md rounded-xl flex justify-between items-start border border-outline-variant/5">
                <div>
                  <div className="font-headline text-2xl font-bold text-on-surface mb-0.5">84ms</div>
                  <div className="text-[11px] text-on-surface-variant font-sans">Prompt Injection Latency</div>
                </div>
                <div className="px-2 py-0.5 bg-emerald-500/10 text-emerald-400 text-[10px] rounded uppercase font-bold tracking-wider font-headline">Active</div>
              </div>

              {/* Guardrail: Data Leakage */}
              <div className="guardrail-glow-emerald bg-surface-container/30 p-md rounded-xl flex justify-between items-start border border-outline-variant/5">
                <div>
                  <div className="font-headline text-2xl font-bold text-on-surface mb-0.5">0.00%</div>
                  <div className="text-[11px] text-on-surface-variant font-sans">PII Leakage Rate</div>
                </div>
                <div className="px-2 py-0.5 bg-emerald-500/10 text-emerald-400 text-[10px] rounded uppercase font-bold tracking-wider font-headline">Active</div>
              </div>
            </div>
          </div>

          <div className="glass-panel rounded-xl p-lg border border-outline-variant/15 mt-lg">
            <h3 className="font-headline text-xs font-semibold text-on-surface-variant uppercase tracking-widest mb-4">Safety Score Heatmap</h3>
            
            <div className="h-28 flex items-end gap-1.5 px-1.5">
              {/* Interactive Heatmap Bars */}
              <div className="flex-1 bg-emerald-500/20 hover:bg-emerald-500/50 rounded h-[90%] transition-all cursor-pointer relative group" title="Hour 0-3: 98%">
                <div className="opacity-0 group-hover:opacity-100 absolute -top-8 left-1/2 -translate-x-1/2 bg-surface px-1.5 py-0.5 rounded text-[9px] font-mono whitespace-nowrap z-20">98%</div>
              </div>
              <div className="flex-1 bg-emerald-500/30 hover:bg-emerald-500/50 rounded h-[85%] transition-all cursor-pointer relative group" title="Hour 3-6: 95%">
                <div className="opacity-0 group-hover:opacity-100 absolute -top-8 left-1/2 -translate-x-1/2 bg-surface px-1.5 py-0.5 rounded text-[9px] font-mono whitespace-nowrap z-20">95%</div>
              </div>
              <div className="flex-1 bg-amber-500/30 hover:bg-amber-500/50 rounded h-[60%] transition-all cursor-pointer relative group" title="Hour 6-9: 78%">
                <div className="opacity-0 group-hover:opacity-100 absolute -top-8 left-1/2 -translate-x-1/2 bg-surface px-1.5 py-0.5 rounded text-[9px] font-mono whitespace-nowrap z-20">78%</div>
              </div>
              <div className="flex-1 bg-emerald-500/25 hover:bg-emerald-500/50 rounded h-[92%] transition-all cursor-pointer relative group" title="Hour 9-12: 99%">
                <div className="opacity-0 group-hover:opacity-100 absolute -top-8 left-1/2 -translate-x-1/2 bg-surface px-1.5 py-0.5 rounded text-[9px] font-mono whitespace-nowrap z-20">99%</div>
              </div>
              <div className="flex-1 bg-emerald-500/40 hover:bg-emerald-500/50 rounded h-[95%] transition-all cursor-pointer relative group" title="Hour 12-15: 100%">
                <div className="opacity-0 group-hover:opacity-100 absolute -top-8 left-1/2 -translate-x-1/2 bg-surface px-1.5 py-0.5 rounded text-[9px] font-mono whitespace-nowrap z-20">100%</div>
              </div>
              <div className="flex-1 bg-red-500/30 hover:bg-red-500/50 rounded h-[30%] transition-all cursor-pointer relative group" title="Hour 15-18: 42% (Anomalies)">
                <div className="opacity-0 group-hover:opacity-100 absolute -top-8 left-1/2 -translate-x-1/2 bg-surface px-1.5 py-0.5 rounded text-[9px] font-mono whitespace-nowrap z-20">42%</div>
              </div>
              <div className="flex-1 bg-emerald-500/20 hover:bg-emerald-500/50 rounded h-[88%] transition-all cursor-pointer relative group" title="Hour 18-21: 94%">
                <div className="opacity-0 group-hover:opacity-100 absolute -top-8 left-1/2 -translate-x-1/2 bg-surface px-1.5 py-0.5 rounded text-[9px] font-mono whitespace-nowrap z-20">94%</div>
              </div>
              <div className="flex-1 bg-emerald-500/30 hover:bg-emerald-500/50 rounded h-[91%] transition-all cursor-pointer relative group" title="Hour 21-24: 97%">
                <div className="opacity-0 group-hover:opacity-100 absolute -top-8 left-1/2 -translate-x-1/2 bg-surface px-1.5 py-0.5 rounded text-[9px] font-mono whitespace-nowrap z-20">97%</div>
              </div>
            </div>

            <div className="flex justify-between mt-2.5 text-[10px] font-mono text-on-surface-variant uppercase">
              <span>00:00</span>
              <span>12:00</span>
              <span>23:59</span>
            </div>
          </div>
        </div>

        {/* Exception Handling Routines (8 columns on desktop) */}
        <div className="md:col-span-8 glass-panel rounded-xl p-lg relative overflow-hidden border border-outline-variant/15 flex flex-col justify-between">
          <h3 className="font-headline text-lg font-bold text-[#e1e2ec] mb-4 z-10">Automated Exception Routines</h3>
          
          <div className="space-y-lg relative z-10 flex-grow">
            {/* Routine 1: API Timeout */}
            <div className="group border border-outline-variant/30 rounded-xl p-lg hover:border-primary/50 transition-all bg-surface-container-low/50">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4">
                <div className="flex items-center gap-md">
                  <div className="w-12 h-12 rounded-xl bg-secondary-container flex items-center justify-center">
                    <span className="material-symbols-outlined text-primary text-2xl">timer_off</span>
                  </div>
                  <div>
                    <h4 className="font-headline text-sm font-bold text-on-surface">API Timeout Handling</h4>
                    <p className="text-xs text-on-surface-variant leading-relaxed">Routine triggered when LLM response exceeds {timeoutLimit}ms.</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <span className="text-mono text-xs text-on-surface-variant font-semibold">v2.4</span>
                  <button 
                    onClick={() => setShowTimeoutModal(true)}
                    className="px-3.5 py-1.5 bg-primary hover:bg-primary/90 text-on-primary font-headline text-xs font-semibold rounded-lg uppercase tracking-wider active:scale-95 cursor-pointer shadow-md shadow-primary/10"
                  >
                    Configure
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="bg-surface-container p-3 rounded-lg border border-outline-variant/10">
                  <div className="text-[10px] text-on-surface-variant mb-0.5 font-semibold">Strategy</div>
                  <div className="text-xs text-on-surface font-mono font-bold">{timeoutStrategy}</div>
                </div>
                <div className="bg-surface-container p-3 rounded-lg border border-outline-variant/10">
                  <div className="text-[10px] text-on-surface-variant mb-0.5 font-semibold">Fallback Node</div>
                  <div className="text-xs text-on-surface font-mono font-bold">{timeoutFallback}</div>
                </div>
                <div className="bg-surface-container p-3 rounded-lg border border-outline-variant/10">
                  <div className="text-[10px] text-on-surface-variant mb-0.5 font-semibold">Last Outage Response</div>
                  <div className="text-xs text-emerald-400 font-mono font-bold">3m ago (Success)</div>
                </div>
              </div>
            </div>

            {/* Routine 2: High Fraud Risk */}
            <div className="group border-l-4 border-red-500 bg-red-500/5 rounded-r-xl p-lg border-y border-r border-outline-variant/20 hover:border-red-500/50 transition-all">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-3">
                <div className="flex items-center gap-md">
                  <div className="w-12 h-12 rounded-xl bg-red-500/10 flex items-center justify-center border border-red-500/20">
                    <span className="material-symbols-outlined text-red-400 text-2xl">gpp_maybe</span>
                  </div>
                  <div>
                    <h4 className="font-headline text-sm font-bold text-on-surface">High Fraud Risk Detection</h4>
                    <p className="text-xs text-on-surface-variant leading-relaxed">Intersects transactional patterns with LLM behavioral analysis.</p>
                  </div>
                </div>
                <div className="px-3 py-1 bg-red-500/15 text-red-400 font-headline text-[10px] font-bold rounded border border-red-500/20 tracking-wider">IMMEDIATE BLOCK</div>
              </div>
              <div className="node-connector-line my-3 opacity-25"></div>
              <div className="flex items-center justify-between text-xs">
                <div className="flex items-center gap-1 text-on-surface-variant font-mono">
                  <span className="material-symbols-outlined text-base">history</span>
                  <span>342 intercepts today</span>
                </div>
                <button 
                  onClick={() => setShowForensicLogs(true)}
                  className="text-red-400 font-bold hover:underline cursor-pointer"
                >
                  View Forensic Logs →
                </button>
              </div>
            </div>

            {/* Routine 3: Prompt Injection */}
            <div className="group border border-outline-variant/30 rounded-xl p-lg hover:border-primary/50 transition-all bg-surface-container-low/50">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-3">
                <div className="flex items-center gap-md">
                  <div className="w-12 h-12 rounded-xl bg-secondary-container flex items-center justify-center">
                    <span className="material-symbols-outlined text-primary text-2xl">psychology_alt</span>
                  </div>
                  <div>
                    <h4 className="font-headline text-sm font-bold text-on-surface">Prompt Injection Guard</h4>
                    <p className="text-xs text-on-surface-variant leading-relaxed">Linguistic sanitization and semantic anchor verification.</p>
                  </div>
                </div>
                <div className="px-2.5 py-1 bg-emerald-500/10 text-emerald-400 text-[10px] rounded font-bold font-headline border border-emerald-500/20 tracking-wider">99.9% ACCURACY</div>
              </div>
              <div className="flex flex-wrap gap-1.5 mt-2">
                <span className="px-2.5 py-0.5 bg-surface-container text-on-surface-variant text-[11px] rounded border border-outline-variant/20 font-mono">jailbreak-v4</span>
                <span className="px-2.5 py-0.5 bg-surface-container text-on-surface-variant text-[11px] rounded border border-outline-variant/20 font-mono">sys-instruction-lock</span>
                <span className="px-2.5 py-0.5 bg-surface-container text-on-surface-variant text-[11px] rounded border border-outline-variant/20 font-mono">context-filter-7b</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Human Intervention Queue (Full Width) */}
      <div className="glass-panel rounded-xl p-lg border border-outline-variant/15 shadow-xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-4">
          <div>
            <h3 className="font-headline text-lg font-bold text-[#e1e2ec]">Human Intervention Queue</h3>
            <p className="text-xs text-on-surface-variant font-sans mt-0.5">Edge cases requiring semantic disambiguation by a Tier 3 Architect.</p>
          </div>
          <div className="flex gap-2">
            <button 
              onClick={handleRefreshQueue}
              className="px-4 py-2 border border-outline-variant text-on-surface rounded-lg font-headline text-xs font-semibold hover:bg-surface-container-high active:scale-95 transition-all cursor-pointer"
            >
              Refresh Queue ({queue.filter(i => i.status === 'Awaiting Review').length})
            </button>
            <button 
              onClick={handleAuditAll}
              className="px-4 py-2 bg-primary text-on-primary rounded-lg font-headline text-xs font-semibold hover:opacity-90 active:scale-95 transition-all cursor-pointer shadow-md shadow-primary/10"
            >
              Audit All
            </button>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-separate border-spacing-y-2 min-w-[700px]">
            <thead>
              <tr className="text-[10px] text-on-surface-variant uppercase tracking-widest bg-surface-container-low/40">
                <th className="py-2 px-md font-bold rounded-l-lg">Timestamp</th>
                <th className="py-2 px-md font-bold">Model Node</th>
                <th className="py-2 px-md font-bold">Risk Factor</th>
                <th className="py-2 px-md font-bold">Ambiguity Score</th>
                <th className="py-2 px-md font-bold">Status</th>
                <th className="py-2 px-md text-right rounded-r-lg font-bold">Action</th>
              </tr>
            </thead>
            <tbody className="font-body-sm text-xs">
              <AnimatePresence>
                {queue.map((row) => (
                  <motion.tr 
                    key={row.id} 
                    initial={{ opacity: 0, y: 4 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, x: -10 }}
                    className={`bg-surface-container/30 hover:bg-surface-container/60 transition-all border border-outline-variant/10 rounded-lg group ${row.status === 'Resolved' || row.status === 'Flagged' ? 'opacity-50' : ''}`}
                  >
                    <td className="py-3 px-md rounded-l-lg text-on-surface-variant font-mono">{row.timestamp}</td>
                    <td className="py-3 px-md text-on-surface font-semibold font-headline">{row.modelNode}</td>
                    <td className="py-3 px-md">
                      <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold border font-headline ${
                        row.riskSeverity === 'critical' ? 'bg-red-500/10 text-red-400 border-red-500/20' :
                        row.riskSeverity === 'moderate' ? 'bg-amber-500/10 text-amber-400 border-amber-500/20' :
                        'bg-blue-500/10 text-blue-400 border-blue-500/20'
                      }`}>
                        {row.riskFactor}
                      </span>
                    </td>
                    <td className="py-3 px-md text-on-surface font-mono">{row.ambiguityScore}% ({row.riskSeverity})</td>
                    <td className="py-3 px-md">
                      {row.status === 'Awaiting Review' ? (
                        <div className="flex items-center gap-1.5 font-sans">
                          <div className="w-2 h-2 rounded-full bg-amber-500 animate-pulse"></div>
                          <span className="text-amber-400 font-semibold text-[11px]">Awaiting Review</span>
                        </div>
                      ) : row.status === 'Resolved' ? (
                        <div className="flex items-center gap-1.5 font-sans text-emerald-400">
                          <span className="material-symbols-outlined text-sm">verified</span>
                          <span className="text-emerald-400 font-semibold text-[11px]">Bypassed/Approved</span>
                        </div>
                      ) : row.status === 'Flagged' ? (
                        <div className="flex items-center gap-1.5 font-sans text-red-400">
                          <span className="material-symbols-outlined text-sm font-semibold">block</span>
                          <span className="text-red-400 font-semibold text-[11px]">Blocked/Locked</span>
                        </div>
                      ) : (
                        <div className="flex items-center gap-1.5 text-on-surface-variant font-sans">
                          <span className="material-symbols-outlined text-sm">lock_person</span>
                          <span className="text-[11px]">Handled by 'J.Doe'</span>
                        </div>
                      )}
                    </td>
                    <td className="py-3 px-md rounded-r-lg text-right">
                      {row.status === 'Awaiting Review' ? (
                        <button 
                          onClick={() => setSelectedIncident(row)}
                          className="text-primary hover:text-primary-container hover:underline font-bold cursor-pointer font-headline tracking-wide"
                        >
                          Investigate
                        </button>
                      ) : (
                        <button className="text-on-surface-variant/40 cursor-not-allowed font-semibold font-headline" disabled>
                          Locked
                        </button>
                      )}
                    </td>
                  </motion.tr>
                ))}
              </AnimatePresence>
            </tbody>
          </table>
        </div>
      </div>

      {/* Investigation Modal */}
      <AnimatePresence>
        {selectedIncident && (
          <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <motion.div 
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="glass-panel w-full max-w-md rounded-2xl border border-outline-variant/30 overflow-hidden shadow-2xl bg-surface-container-low"
            >
              <div className="bg-surface-container-high px-lg py-md border-b border-outline-variant/20 flex justify-between items-center">
                <div className="flex items-center gap-2">
                  <span className="material-symbols-outlined text-primary">visibility_lock</span>
                  <h3 className="font-headline text-base font-bold text-on-surface">Incident Investigation</h3>
                </div>
                <button 
                  onClick={() => setSelectedIncident(null)}
                  className="p-1 hover:bg-surface-container-highest rounded-full text-on-surface-variant cursor-pointer"
                >
                  <span className="material-symbols-outlined">close</span>
                </button>
              </div>

              <div className="p-lg space-y-md">
                <div className="space-y-1">
                  <span className="text-[10px] text-on-surface-variant uppercase font-bold tracking-wider font-headline">Target Model Node</span>
                  <div className="text-sm font-semibold font-headline text-white">{selectedIncident.modelNode}</div>
                </div>

                <div className="grid grid-cols-2 gap-sm pt-1">
                  <div>
                    <span className="text-[10px] text-on-surface-variant uppercase font-bold tracking-wider block font-headline">Anomaly Factor</span>
                    <span className="text-xs font-mono font-semibold text-primary">{selectedIncident.riskFactor}</span>
                  </div>
                  <div>
                    <span className="text-[10px] text-on-surface-variant uppercase font-bold tracking-wider block font-headline">Ambiguity Score</span>
                    <span className="text-xs font-mono font-semibold text-tertiary">{selectedIncident.ambiguityScore}% Match</span>
                  </div>
                </div>

                <div className="space-y-1.5 pt-2 border-t border-outline-variant/10">
                  <span className="text-xs font-bold text-on-surface font-headline block">Security Narrative</span>
                  <p className="text-xs text-on-surface-variant leading-relaxed">
                    {selectedIncident.details || "The request triggered context limits on the compliance vector scanner. Internal data formats contain keywords conflicting with normal customer behaviors."}
                  </p>
                </div>

                <div className="pt-4 border-t border-outline-variant/10 flex gap-2">
                  <button 
                    onClick={() => handleResolveIncident('Resolved')}
                    className="flex-1 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-semibold font-headline tracking-wide cursor-pointer text-center"
                  >
                    Bypass Guardrail
                  </button>
                  <button 
                    onClick={() => handleResolveIncident('Flagged')}
                    className="flex-1 py-2.5 bg-red-600 hover:bg-red-700 text-white rounded-lg text-xs font-semibold font-headline tracking-wide cursor-pointer text-center"
                  >
                    Enforce Lock (Block)
                  </button>
                </div>
              </div>

              <div className="bg-surface-container-high/40 px-lg py-3 border-t border-outline-variant/15 text-[10px] text-on-surface-variant font-mono">
                Investigator: Master Admin Session
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Timeout Configuration Modal */}
      <AnimatePresence>
        {showTimeoutModal && (
          <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <motion.div 
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="glass-panel w-full max-w-md rounded-2xl border border-outline-variant/40 overflow-hidden shadow-2xl bg-surface-container-low"
            >
              <div className="bg-surface-container-high px-lg py-md border-b border-outline-variant/20 flex justify-between items-center">
                <div className="flex items-center gap-2">
                  <span className="material-symbols-outlined text-primary">timer</span>
                  <h3 className="font-headline text-base font-bold text-on-surface">API Timeout Configuration</h3>
                </div>
                <button 
                  onClick={() => setShowTimeoutModal(false)}
                  className="p-1 hover:bg-surface-container-highest rounded-full text-on-surface-variant cursor-pointer"
                >
                  <span className="material-symbols-outlined">close</span>
                </button>
              </div>

              <div className="p-lg space-y-md">
                <div className="space-y-2">
                  <div className="flex justify-between items-center text-xs font-semibold">
                    <span className="text-on-surface-variant">Timeout Trigger Limit</span>
                    <span className="text-primary font-mono">{timeoutLimit}ms</span>
                  </div>
                  <input 
                    type="range" 
                    min="1000" 
                    max="10000" 
                    step="500"
                    value={timeoutLimit}
                    onChange={(e) => setTimeoutLimit(Number(e.target.value))}
                    className="w-full h-1.5 bg-surface-container-highest rounded-lg appearance-none cursor-pointer accent-primary"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-semibold text-on-surface-variant block">Backoff Strategy</label>
                  <select 
                    value={timeoutStrategy} 
                    onChange={(e) => setTimeoutStrategy(e.target.value)}
                    className="w-full bg-surface-container-highest border border-outline-variant/30 rounded-lg px-3 py-2 text-xs focus:outline-none text-white focus:border-primary"
                  >
                    <option value="Exponential Backoff">Exponential Backoff (Recommended)</option>
                    <option value="Linear Increment">Linear Increment</option>
                    <option value="Immediate Error Escalation">Immediate Error Escalation</option>
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="text-xs font-semibold text-on-surface-variant block">Fallback LLM Endpoint</label>
                  <select 
                    value={timeoutFallback} 
                    onChange={(e) => setTimeoutFallback(e.target.value)}
                    className="w-full bg-surface-container-highest border border-outline-variant/30 rounded-lg px-3 py-2 text-xs focus:outline-none text-white focus:border-primary"
                  >
                    <option value="Local TinyLlama">Local TinyLlama (Edge Deploy)</option>
                    <option value="Gemini Flash Backup">Gemini 1.5 Flash Backup (Cloud)</option>
                    <option value="Offline Cached Resolution">Offline Cached Resolution Engine</option>
                  </select>
                </div>
              </div>

              <div className="bg-surface-container-high/50 px-lg py-md border-t border-outline-variant/20 flex justify-end gap-3">
                <button 
                  onClick={() => setShowTimeoutModal(false)}
                  className="px-4 py-2 border border-outline-variant hover:bg-surface-container-highest rounded-lg text-xs font-headline font-semibold text-on-surface cursor-pointer"
                >
                  Close
                </button>
                <button 
                  onClick={() => setShowTimeoutModal(false)}
                  className="px-4 py-2 bg-primary text-on-primary hover:opacity-90 rounded-lg text-xs font-headline font-semibold cursor-pointer"
                >
                  Apply Strategy
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Forensic Logs Drawer */}
      <AnimatePresence>
        {showForensicLogs && (
          <div className="fixed inset-y-0 right-0 w-full max-w-lg bg-[#020205]/95 backdrop-blur-md border-l border-white/10 z-50 shadow-2xl flex flex-col justify-between">
            <div>
              <div className="bg-surface-container-high px-lg py-md border-b border-outline-variant/20 flex justify-between items-center">
                <div className="flex items-center gap-2">
                  <span className="material-symbols-outlined text-red-400">gpp_maybe</span>
                  <h3 className="font-headline text-base font-bold text-on-surface">Forensic Audit Stream</h3>
                </div>
                <button 
                  onClick={() => setShowForensicLogs(false)}
                  className="p-1 hover:bg-surface-container-highest rounded-full text-on-surface-variant cursor-pointer"
                >
                  <span className="material-symbols-outlined">close</span>
                </button>
              </div>

              <div className="p-lg font-mono text-xs space-y-3 max-h-[calc(100vh-120px)] overflow-y-auto">
                {forensicLogs.map((log, index) => (
                  <div key={index} className="pb-2.5 border-b border-outline-variant/5 text-red-300">
                    <div className="text-[10px] text-on-surface-variant font-sans">Timestamp: {new Date().toTimeString().split(' ')[0]} PST</div>
                    <p className="mt-1 leading-relaxed">{log}</p>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-surface-container px-lg py-md border-t border-outline-variant/20 flex justify-between items-center">
              <span className="text-[11px] font-mono text-on-surface-variant">Real-time threat feeds (Active)</span>
              <button 
                onClick={() => setForensicLogs([])}
                className="text-xs text-red-400 hover:underline cursor-pointer"
              >
                Clear Stream
              </button>
            </div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
